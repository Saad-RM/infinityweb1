# login-with-steam-php
A simple login with discord button using javascript and express js

## Video Tutorial:
https://youtu.be/0y-DsaI3ZcM


## Written Guide:
[https://cindr.org/how-to-make-a-login-with-steam-button-with-php-oauth-open/](https://cindr.org/how-to-make-a-login-with-discord-button-using-javascript-express/)



